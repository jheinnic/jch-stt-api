declare module "worker-loader!*" {
    const content: any;
    export = content;
}