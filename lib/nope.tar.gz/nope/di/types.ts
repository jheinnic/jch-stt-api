const TYPES = {
   STTApi: Symbol.for("Warrior"),
   ImageCache: Symbol.for("Weapon"),
   QuestsTable: Symbol.for("QuestsTable"),
   ImmortalsTable: Symbol.for("ImmortalsTable"),
   WikiImagesTable: Symbol.for("WikiImagesTable"),
   ConfigTable: Symbol.for("ConfigTable"),
};

export { TYPES };
